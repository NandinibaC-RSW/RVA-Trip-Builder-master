document.addEventListener("DOMContentLoaded", function() { 


//Autocomplete For Destination City address
var isStartingAddressChange = false;
var destination_city = document.getElementById('get_address');
var autocomplete = new google.maps.places.Autocomplete(destination_city);
google.maps.event.addListener(autocomplete, 'place_changed', function () {
    var place = autocomplete.getPlace();
    jQuery('#address_lat').val(place.geometry.location.lat());
    jQuery('#address_lng').val(place.geometry.location.lng());
    IsSearchCityChange = true;
});

//Autocomplete For starting address
var IsSearchCityChange=false;
var inputStartingAddress = document.getElementById('trip_starting_address');
var autocompleteStartingAddress = new google.maps.places.Autocomplete(inputStartingAddress);
google.maps.event.addListener(autocompleteStartingAddress, 'place_changed', function () {
    var place = autocompleteStartingAddress.getPlace();
    jQuery('#starting_address_lat').val(place.geometry.location.lat());
    jQuery('#starting_address_lang').val(place.geometry.location.lng());
    isStartingAddressChange = true;
});

//Autocomplete For ending address
var isEndingAddressChange = false;
var inputEndingAddress = document.getElementById('trip_ending_address');
var autocompleteEndingAddress = new google.maps.places.Autocomplete(inputEndingAddress);
google.maps.event.addListener(autocompleteEndingAddress, 'place_changed', function () {
    var place = autocompleteEndingAddress.getPlace();
    jQuery('#ending_address_lat').val(place.geometry.location.lat());
    jQuery('#ending_address_lang').val(place.geometry.location.lng());
    isEndingAddressChange = true;
    });


//Autocomplete For destination popup
var isDestAddressChange = false;
var inputDestAddress = document.getElementById('dest_address');
var autocompleteDestAddress = new google.maps.places.Autocomplete(inputDestAddress);
google.maps.event.addListener(autocompleteDestAddress, 'place_changed', function () {
    var place = autocompleteDestAddress.getPlace();
    jQuery('#dest_address_lat').val(place.geometry.location.lat());
    jQuery('#dest_address_lag').val(place.geometry.location.lng());
    isDestAddressChange = true;
    });
});

jQuery(document).ready(function($){
    var mediaUploader;

    $('#upload-image-button').click(function(e) {
        e.preventDefault();
        if (mediaUploader) {
            mediaUploader.open();
            return;
        }

        mediaUploader = wp.media.frames.file_frame = wp.media({
            title: 'Choose Image',
            button: {
                text: 'Choose Image'
            },
            multiple: false
        });

        mediaUploader.on('select', function() {
            var attachment = mediaUploader.state().get('selection').first().toJSON();
            $('#destination-image').val(attachment.url);
            $('#image-preview').html('<img src="'+attachment.url+'" style="max-width: 200px; height: auto;" />');
        });

        mediaUploader.open();
    });
    $('#upload_document_button').click(function() {
        var customUploader = wp.media({
            title: 'Select Documents',
            button: {
                text: 'Select'
            },
            multiple: true
        });

        customUploader.on('select', function() {
            var attachment = customUploader.state().get('selection').toJSON();
            var attachmentIds = [];
            attachment.forEach(function(item) {
                attachmentIds.push(item.id);
            });
            $('#upload_document').val(attachmentIds.join(','));

            // AJAX request to update post meta
            var postId = $('#post_id').val();
            var days = $('#days').val();
            var data = {
                action: 'upload_documents', // WordPress AJAX action hook
                post_id: postId,
                day: days,
                attachment_ids: attachmentIds.join(',')
            };

            $.ajax({
                type: 'POST',
                url: ajaxurl, // WordPress AJAX URL variable
                data: data,
                success: function(response) {
                    console.log('Post meta updated successfully.');
                    window.location.reload();
                }
            });
        });

        customUploader.open();
    });
    $('#upload_trip_document_button').click(function() {
        var customUploader = wp.media({
            title: 'Select Documents',
            button: {
                text: 'Select'
            },
            multiple: true
        });

        customUploader.on('select', function() {
            var attachment = customUploader.state().get('selection').toJSON();
            var attachmentIds = [];
            attachment.forEach(function(item) {
                attachmentIds.push(item.id);
            });
            $('#upload_trip_document').val(attachmentIds.join(','));

            // AJAX request to update post meta
            var postId = $('#post_id').val();
            var data = {
                action: 'upload_trip_documents', // WordPress AJAX action hook
                post_id: postId,
                attachment_ids: attachmentIds.join(',')
            };

            $.ajax({
                type: 'POST',
                url: ajaxurl, // WordPress AJAX URL variable
                data: data,
                success: function(response) {
                    console.log('Post meta updated successfully.');
                    window.location.reload();
                }
            });
        });

        customUploader.open();
    });
});

jQuery(document).ready(function($) {
    $(".view-button").on("click", function(event) {
        event.preventDefault();
        var pdfUrl = $(this).attr("href");

        // Embed the PDF directly in the .pdf-container div
        $(".pdf-container").html('<embed src="' + pdfUrl + '" type="application/pdf" width="100%" height="600px" />');

        // Show the modal
        $(".modal").css("display", "block");
    });

    // Close the modal when the close button (×) is clicked
    $(".close").on("click", function() {
        $(".modal").css("display", "none");
        // Clear the .pdf-container content when closing the modal
        $(".pdf-container").html('');
    });

     $(".add-dest").on("click", function(event) {
        //event.preventDefault();
        $(".add-dest-modal").css("display", "block");
    });

    // Close the modal when the close button (×) is clicked
    $(".closes").on("click", function() {
        $(".add-dest-modal").css("display", "none");
    });

    $('#destination-form').submit(function(e) {
    e.preventDefault();

    var formData = $(this).serialize();
     
     $.ajax({
            url: ajaxurl, // WordPress AJAX URL
            type: 'POST',
            data: {
                action: 'add_destination',
                form_data: formData
            },
            success: function(response) {
                $('#destination-form')[0].reset();    
                update_dest(response.data.destination_category);
                $(".add-dest-modal").css("display", "none");
            }
        });
    });
});

jQuery(document).ready(function($) {
    // Listen for changes in the customer selection
    $('#trip_customer_id').on('change', function() {
        var customerId = $(this).val();
        // Perform an AJAX request to get customer data based on the selected ID
        $.ajax({
            url: ajaxurl, // WordPress AJAX URL
            type: 'POST',
            data: {
                action: 'get_customer_data',
                customer_id: customerId
            },
            success: function(response) {
                // Parse the JSON response from the server
                var customerData = $.parseJSON(response);

                // Prefill the input fields with customer data
                $('#trip-customer-first-name').val(customerData.first_name);
                $('#trip-customer-last-name').val(customerData.last_name);
                $('#trip-email').val(customerData.email);
                $('#trip-phone').val(customerData.phone);
                $('#trip-password').val(customerData.password);
            }
        });
        if(customerId == 0){
            $(".customer-div").css("display", "block");
        }else{
            $(".customer-div").css("display", "none");
        }
    });


    $('#destination_categorys').on('change', function() {
        var destination_cat = $(this).val();

        update_dest(destination_cat);
    });

});

function update_dest(destination_cat) {

            $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'change_destinations',
                destination_cat: destination_cat
            },
            success: function(response) {
                  $('#destination').html(response);
            }
        });
}

function initMap() {
  const map = new google.maps.Map(document.getElementById("map"), {
    zoom: 4,
    center: { lat: 37.0902, lng: -95.7129 }, // USA.
  });
  const directionsService = new google.maps.DirectionsService();
  const directionsRenderer = new google.maps.DirectionsRenderer({
    draggable: true,
    map,
    panel: document.getElementById("panel"),
  });

  directionsRenderer.addListener("directions_changed", () => {
    const directions = directionsRenderer.getDirections();

    if (directions) {
      computeTotalDistance(directions);
    }
  });
    var startingAddress = document.getElementById("trip_starting_address").value;
    var endingAddress = document.getElementById("trip_ending_address").value;
    const selectElement = Object.values(selectedDestinations);

    // Format the array in the desired structure
    const waypoints = selectElement.map((destination, index) => {
        return {
            location: destination.address
        };
    });

    displayRoute(
      startingAddress,
      endingAddress,
      waypoints,
      directionsService,
      directionsRenderer
    );
    }

function displayRoute(origin, destination, waypoints, service, display) {
    waypoints = waypoints.filter((waypoint) => waypoint && waypoint.location);
    if (waypoints.length === 0) {
      service
        .route({
          origin: origin,
          destination: destination,
          travelMode: google.maps.TravelMode.DRIVING,
          avoidTolls: true,
        })
        .then((result) => {
          display.setDirections(result);
        })
        .catch((e) => {
          alert("Could not display directions due to: " + e);
        });
  }else{
  service
    .route({
      origin: origin,
      destination: destination,
      waypoints: waypoints,
      travelMode: google.maps.TravelMode.DRIVING,
      avoidTolls: true,
    })
    .then((result) => {
      display.setDirections(result);
    })
    .catch((e) => {
      alert("Could not display directions due to: " + e);
    });
  }
}

function computeTotalDistance(result) {
  let total = 0;
  const myroute = result.routes[0];

  if (!myroute) {
    return;
  }

  for (let i = 0; i < myroute.legs.length; i++) {
    total += myroute.legs[i].distance.value;
  }

  total = total / 1000;
  document.getElementById("total").innerHTML = total + " km";
  // const direction = result.routes[0].legs;
  const direction = result.routes[0].legs;
  direction_data(direction);
}

function direction_data(data) {
  const response = JSON.stringify(data);
  var postId = $('#post_id').val();
  var day = $('#day_count').val();
  var ajaxData = {
    'action': 'update_route_data',
    'postId': postId,
    'day': day,
    'data'  : response,
  }
  jQuery.post( ajax_object.ajaxurl, ajaxData, function(response){ 
    if(response){
      console.log('updated successfully');
    }else{  
    console.log('failed to update');  
  }
  });
}
window.initMap = initMap;

$(document).ready(function() {
    // Populate selected destinations from the database
    if (selectedDestinations) {
        $("#selected-options-container").append("<h4>Selected Destinations:</h4>");
        Object.keys(selectedDestinations).forEach(function(destinationId) {
            var destination = selectedDestinations[destinationId];
            var destination_id = selectedDestinations[destinationId].destination_id;
            if (destination && destination.address && destination_id) {
                var listItem = $("<li>").addClass("selected-option").text(destination.address).attr("value", destination_id).append(" <button class='preview button remove-option' data-value='" + destination_id + "'>Remove</button>");
                $("#selected-options-container").append(listItem);
                // Disable the selected option in the dropdown
                $("#destination option[value='" + destination_id + "']").prop("disabled", true);
            }
        });
    }

    // Handle destination selection
    $("#destination").on("change", function() {
        var selectedOptions = $("#destination option:selected");

        selectedOptions.each(function() {
            var optionText = $(this).text();
            var optionValue = $(this).val();
            // Check if the option is already in the selected list
            if ($("#selected-options-container li[value='" + optionValue + "']").length === 0) {
                var listItem = $("<li>").addClass("selected-option");
                var removeButton = $("<button>")
                    .addClass("preview button remove-option")
                    .data("value", optionValue)
                    .text("Remove");

                removeButton.on("click", function() {
                    // Remove both the selected option and the remove button
                    listItem.remove();
                    $("#destination option[value='" + optionValue + "']").prop("selected", false).prop("disabled", false);
                });

                listItem.text(optionText).append(removeButton);
                listItem.attr("value", optionValue);
                $("#selected-options-container").append(listItem);
                // Disable the selected option in the dropdown
                $("#destination option[value='" + optionValue + "']").prop("disabled", true);
            }
        });
    });

    // Handle remove button click event
    $(document).on("click", ".remove-option", function() {
        var optionValue = $(this).data("value");
        // Remove the selected option from the list
        $(this).parent().remove();
        // Enable the removed option in the dropdown
        $("#destination option[value='" + optionValue + "']").prop("disabled", false);
    });

    // Update the selected values input before form submission
    $(".preview").on("click", function() {
        var selectedValuesArray = [];
        $("#selected-options-container li").each(function() {
            var value = $(this).attr("value");
            selectedValuesArray.push(value);
        });
        $("#selected-values-input").val(selectedValuesArray);
    });
});
