<?php

add_shortcode( 'trip-builder-home', 'wpdocs_bartag_func' );

function wpdocs_bartag_func( $atts ) {
    
    if (!is_user_logged_in() ) {
         wp_redirect(get_site_url());
         exit;
    }

    if (wp_doing_ajax()) {
        return;
    }

    if (isset($_POST['delete_route'])) {
        $trip_stay = $_GET['trip_stay'];
        $post_id = $_POST['delete_route'];
        $destination_id = $_POST['destination_id'];
        $selected_destination_name = "_selected_destinations_" . $trip_stay;
        $selected_destinations = get_post_meta($post_id, $selected_destination_name, true);
        if (isset($selected_destinations[$destination_id])) {
            unset($selected_destinations[$destination_id]);

            update_post_meta($post_id, $selected_destination_name, $selected_destinations);
        }

        wp_redirect('?trip_id=' . $post_id .'&trip_stay=' . $trip_stay);
        exit;
    }



    ob_start();
    $customer_id = get_current_user_id();
    $user = get_user_by('id', $customer_id);

    echo '
    <div class="container_area">';

    if($user){ 

    $args = array(
        'post_type' => 'trip',
        'posts_per_page' => -1,
        'meta_query' => array(
            array(
                'key' => '_trip_customer_id',
                'value' => $customer_id,
                'compare' => '=',
            ),
        ),
        'orderby' => 'date',
        'order' => 'DESC',
    );

    $posts = get_posts($args);
    $number_of_posts = count($posts);

    if ($posts) {
      if (isset($_GET['trip_id'])){
        $post_id = $_GET['trip_id'];   
      }else{
        $post_id = $posts[0]->ID;  
      }
     $trip_title = get_the_title($post_id); 
     $trip_description = get_post_meta( $post_id, '_trip_description', true );

     $trip_start_date = get_post_meta( $post_id, '_trip_start_date', true );
     $trip_starting_address = get_post_meta( $post_id, '_trip_starting_address', true );
     $trip_ending_address = get_post_meta( $post_id, '_trip_ending_address', true );
     $trip_phone = get_post_meta( $post_id, '_trip_phone', true );

     if (isset($_GET['trip_id']) && !isset($_GET['trip_stay']) && !isset($_GET['dest'])) {
         $upload_document_trips = get_post_meta($post_id, '_upload_document_trip', true);
                $upload_document_trip = explode(",", $upload_document_trips);
    echo '<div class="content_section">
            <div class="content_area">
                <h3> ' . $trip_title  . ' </h3>
                <p>'. $trip_description .'</p>';

                if(!empty($upload_document_trips)){
                    echo '<div class="upload_btn_wrapper">
                                    <form class="form_data">';
                                        echo '<a class="upload_btn" id="uploadButton">Download Docs</a>
                                    </form>
                                </div>';
                }

            echo '<div class="download_popup" style="display:none;">
                <div class="download-popup-content">
                <span class="close">&times;</span>';
                        echo '<table class="widefat"><tbody>
                        <h4>Download document</h4>';
                    foreach ($upload_document_trip as $value) {
                        $file_path = get_attached_file($value);
                        $file_name = basename($file_path);
                        $file_url = wp_get_attachment_url($value);
                         echo '<tr>
                            <td><b>'. $file_name .'</b></td>
                            <td class="wrap-right">
                            <a class="download_btn" href="'. esc_url($file_url) .'" download>Download</a><br>
                            </td>
                        </tr>';
                    }
                    echo '</tbody>
                        </table></div></div>'; 
              echo  '<div class="venus">
                    <h6>Starting date: '. date($trip_start_date) .'</h6>
                    <h6>Starting location: '. $trip_starting_address .'</h6>
                </div>
            </div>';

        $day = get_post_meta($post_id, '_trip_day_count', true);
        $trip_end_date = date('Y-m-d', strtotime($trip_start_date . ' + ' . $day . ' days'));
        for ($i=1; $i <= $day; $i++) { 

        $current_route = "_route_" . $i;
        $current_title = "_route_title_" . $i;    
        $current_value = get_post_meta($post_id, $current_route, true);
        
        if ($current_value) {
            $current_title = get_post_meta($post_id, $current_title, true);

            echo'<div class="day_section_part">
            <div class="day_section">
                <a href="?trip_id='. $post_id .'&trip_stay='. $i .'">
                <div class="day_btn">'. $current_title .'<i class="fa-solid fa-chevron-right"></i>
                </div>
                </a>
            </div>
        </div>';
        } else {
            continue;
        }
    }

   echo '<div class="content_area">
                <div class="venus">
                    <h6>Ending date: '. date($trip_end_date) .'</h6>
                    <h6>Ending location: ' . $trip_ending_address . '</h6>
                </div>
            </div>';
   if ($number_of_posts > 1) {
        echo '<div class="next_pri">
                <a href="trip-builder-home" class="btn">Back</a>';               
        echo '</div>';
        }   
        echo '</div>';

     }elseif (isset($_GET['trip_stay']) && !isset($_GET['dest'])) {

        function numberToWords($number) {
            $words = array('zero', 'one', 'two', 'three', 'four', 'five', 'six', 'seven', 'eight', 'nine');
            return $words[$number] ?? '';
        }
        $day = $_GET['trip_stay'];
        $dayInWords = numberToWords($day);

        $day_start_address_name = "_route_day_start_address_" .$day;
        $day_end_address_name = "_route_day_end_address_" .$day;
        $destination_name = "_route_destination_" .$day;
        $route_title_name = "_route_title_" .$day;
        $route_time_name = "_route_time_" .$day;
        $route_name = "_route_" .$day;
        $start_lat_route_name = "_route_day_start_address_lat_" .$day;
        $start_lng_route_name = "_route_day_start_address_lng_" .$day;
        $end_lat_route_name = "_route_day_end_address_lat_" .$day;
        $end_lng_route_name = "_route_day_end_address_lng_" .$day;
        $upload_document_name = "_upload_document_day_" .$day;


        $trip_day_starting_address = get_post_meta($post_id, $day_start_address_name, true);
        $trip_day_ending_address = get_post_meta($post_id, $day_end_address_name, true);
        $route_title = get_post_meta($post_id, $route_title_name, true);
        $route_time = get_post_meta($post_id, $route_time_name, true);
        $route_data = get_post_meta($post_id, $route_name);
        $start_lat = get_post_meta($post_id, $start_lat_route_name, true);
        $start_lng = get_post_meta($post_id, $start_lng_route_name, true);
        $end_lat = get_post_meta($post_id, $end_lat_route_name, true);
        $end_lng = get_post_meta($post_id, $end_lng_route_name, true);
        $destination = get_post_meta($post_id, $destination_name, true);
        $destination_post = get_post($destination);
        $upload_documents = get_post_meta($post_id, $upload_document_name, true);
        $upload_document = explode(",", $upload_documents);
    
    echo '<div class="content_section">
            <div class="one_day">
                <div class="one_day_heading">
                     <h3>'. $route_title .'</h3>
                </div>
                <div class="close_btn">
                    <a href="trip-builder-home"><i class="fa-regular fa-circle-xmark"></i></a>
                </div>
            </div>
            <div class="one_day_description">
                <p>'. $trip_description .'</p>
            </div>';
            if(!empty($upload_documents)){
                echo '<div class="upload_btn_wrapper">
                        <form class="form_data">';
                            echo '<a class="upload_btn" id="uploadButton">Download Docs</a>
                        </form>
                    </div>';
            }

            echo '<div class="download_popup" style="display:none;">
                <div class="download-popup-content">
                <span class="close">&times;</span>';
                        echo '<table class="widefat"><tbody>
                        <h4>Download document</h4>';
                    foreach ($upload_document as $value) {
                        $file_path = get_attached_file($value);
                        $file_name = basename($file_path);
                        $file_url = wp_get_attachment_url($value);
                         echo '<tr>
                            <td><b>'. $file_name .'</b></td>
                            <td class="wrap-right">
                            <a class="download_btn" href="'. esc_url($file_url) .'" download>Download</a><br>
                            </td>
                        </tr>';
                    }
                    echo '</tbody>
                        </table></div></div>'; 
            echo '<div class="address_section">
                <div class="address_text">
                    <h4>Starting Address:</h4>
                    <p> '. $trip_day_starting_address .'</p>
                </div>
                <div class="down_arrow">
                    <i class="fa-solid fa-arrow-turn-down"></i>
                </div>
            </div>';

            // Retrieve selected destinations for the specific day
            $selected_destination_name = "_selected_destinations_" . $day;
            $selected_destinations = get_post_meta($post_id, $selected_destination_name, true);
            $destination_category_name = "_route_destination_category_" . $day;
            $destination_category = get_post_meta($post_id, $destination_category_name, true);
            $term = get_term($destination_category, 'destination_category');

            // Check if there are selected destinations
            if (!empty($selected_destinations && $term->name == 'Point of Interest')) {
                $counter = 0;
                foreach ($selected_destinations as $destination_id => $destination_details) {
                    $destination_post = get_post($destination_id);
                    $destination_address = $destination_details['address'];
                    $destination_description = get_post_meta($destination_id, '_destination_description', true);
                    $dest_phone = get_post_meta($destination_id, '_destination_phone', true);
                    $dest_website = get_post_meta($destination_id, '_destination_website', true);

                    echo '<div class="destination_section">';
                    echo '<h4 class="heading">Place of Interest:</h4>';
                    echo '<div class="destinations_area">';
                    echo '<h4 class="heading">' . esc_html($destination_post->post_title) . '</h4>';
                    $image_url =  get_post_meta( $destination_id, '_destination_image', true ) ;
                    if ($image_url) {
                        echo '<div class="location_icon">
                                <img class="dest-img" src="' . esc_url($image_url) . '" alt="' . esc_html($destination_post->post_title) . '">
                              </div>';
                    }else{
                        echo '<div class="location_icon">
                            <i class="fa-solid fa-location-dot"></i>
                        </div>';
                    }
                    echo '<div class="map_location">
                            <a class="remove_dest" href="?trip_id='. $post_id .'&trip_stay=' . $day .'&dest=' . $destination_post->ID .'">remove</a>
                        </div>
                    </div>
                </div>';

                    $response_data = get_post_meta($post_id, '_direction_data_'.$post_id.'_'.$day, true);
                    $response_json = json_decode($response_data);
                    $direction_symbols = array(
                                            'head' => '↑',
                                            'uturn-right' => '↩',
                                            'uturn-left' => '↪',
                                            'turn-right' => '→',
                                            'turn-left' => '←',
                                            'turn-slight-right' => '⤤',
                                            'turn-slight-left' => '⤦', 
                                            'ramp-right' => '⇥',
                                            'ramp-left' => '⇤', 
                                            'fork-right' => '⇢', 
                                            'fork-left' => '⇠', 
                                            'merge' => '↔', 
                                            'roundabout-right' => '↻',
                                            'roundabout-left' => '↺',
                                            'straight' => '↑',
                                            'keep-right' => '↗',
                                            'keep-left' => '↖',
                                            'slight-right' => '→',
                                            'slight-left' => '←',
                                            'sharp-right' => '⇒',
                                            'sharp-left' => '⇐',
                                            'right' => '→', 
                                            'left' => '←', 
                                        );
                    foreach ($response_json as $route => $directiondata) {
                        if($counter == $route){
                        echo '<div class="directions_section">';
                        echo '<h6 class="heading">Turn-by-Turn Directions: <span class="circle-icon"><i class="fas fa-chevron-down"></i></span></h6>';
                        echo '<div class="directions_content">';
                        foreach ($directiondata->steps as $step) {
                            if(!empty($step->maneuver)){
                                $text_direction = strtolower($step->maneuver);
                                $direction_symbol = isset($direction_symbols[$text_direction]) ? $direction_symbols[$text_direction] : '';
                            } else {
                                $direction_symbol = "";
                            }
                            echo '<div class="distance_part">
                                    <div class="above_arrow">
                                        <span style="font-size:30px;">' . $direction_symbol . '</span>
                                    </div>';
                            echo '<div class="place_name">
                                    <p>' . $step->instructions . '</p>
                                    <span>' . $step->duration->text . ' ( ' . $step->distance->text . ' )</span>
                                </div>
                            </div>';
                        }
                        echo '</div></div>';
                    }}
                $counter++;
                }
            echo '<div class="address_section">
                            <div class="address_text">
                                <h4>Ending Address:</h4>
                                <p> '. $trip_day_ending_address .'</p>
                            </div>
                        </div>';
            
            $counter+1;
            foreach ($response_json as $route => $directiondata) {
                if($counter == $route){
                echo '<div class="directions_section">';
                echo '<h6 class="heading">Turn-by-Turn Directions: <span class="circle-icon"><i class="fas fa-chevron-down"></i></span></h6>';
                echo '<div class="directions_content">';
                foreach ($directiondata->steps as $step) {
                    if(!empty($step->maneuver)){
                        $text_direction = strtolower($step->maneuver);
                        $direction_symbol = isset($direction_symbols[$text_direction]) ? $direction_symbols[$text_direction] : '';
                    } else {
                        $direction_symbol = "";
                    }
                    echo '<div class="distance_part">
                            <div class="above_arrow">
                                <span style="font-size:30px;">' . $direction_symbol . '</span>
                            </div>';
                    echo '<div class="place_name">
                            <p>' . $step->instructions . '</p>
                            <span>' . $step->duration->text . ' ( ' . $step->distance->text . ' )</span>
                        </div>
                    </div>';
                }
                echo '</div></div>';
        }}

            }elseif(!empty($selected_destinations)){
                $counter = 0;
                foreach ($selected_destinations as $destination_id => $destination_details) {
                    $destination_post = get_post($destination_id);
                    $destination_title = $destination_post->post_title;
                    $destination_address = $destination_details['address'];
                    $destination_description = get_post_meta($destination_id, '_destination_description', true);
                    $dest_phone = get_post_meta($destination_id, '_destination_phone', true);
                    $dest_website = get_post_meta($destination_id, '_destination_website', true);

                    echo '<div class="destination_section">
                            <h4 class="heading">Destination:</h4>
                        <div class="map_location">
                            <h4 class="heading">' . esc_html($destination_title) . '</h4>
                        </div>
                    <div class="destinations_area">
                        <div class="location_icon">
                            <p>' . esc_html($destination_address) . '</p>
                            <i class="fa-solid fa-location-dot"></i>
                        </div>
                    </div>
                    <div class="btn_section">
                        <a href="tel:' . $trip_phone . '" class="btn">Call</a>
                        <a href="' . $dest_website . '" target="_new" class="btn">website</a>
                    </div>
                </div>';

                    $response_data = get_post_meta($post_id, '_direction_data_'.$post_id.'_'.$day, true);
                    $response_json = json_decode($response_data);
                    foreach ($response_json as $route => $directiondata) {
                        if($counter == $route){
                        echo '<div class="directions_section">';
                        echo '<h6 class="heading">Turn-by-Turn Directions: <span class="circle-icon"><i class="fas fa-chevron-down"></i></span></h6>';
                        echo '<div class="directions_content">';
                        foreach ($directiondata->steps as $step) {
                            if(!empty($step->maneuver)){
                                $text_direction = strtolower($step->maneuver);
                                $direction_symbol = isset($direction_symbols[$text_direction]) ? $direction_symbols[$text_direction] : '';
                            } else {
                                $direction_symbol = "";
                            }
                            echo '<div class="distance_part">
                                    <div class="above_arrow">
                                        <span style="font-size:30px;">' . $direction_symbol . '</span>
                                    </div>';
                            echo '<div class="place_name">
                                    <p>' . $step->instructions . '</p>
                                    <span>' . $step->duration->text . ' ( ' . $step->distance->text . ' )</span>
                                </div>
                            </div>';
                        }
                        echo '</div></div>';
                    }}
                $counter++;
                }
            echo '<div class="address_section">
                            <div class="address_text">
                                <h4>Ending Address:</h4>
                                <p> '. $trip_day_ending_address .'</p>
                            </div>
                        </div>';
            
            $counter+1;
            foreach ($response_json as $route => $directiondata) {
                if($counter == $route){
                echo '<div class="directions_section">';
                echo '<h6 class="heading">Turn-by-Turn Directions: <span class="circle-icon"><i class="fas fa-chevron-down"></i></span></h6>';
                echo '<div class="directions_content">';
                foreach ($directiondata->steps as $step) {
                    if(!empty($step->maneuver)){
                        $text_direction = strtolower($step->maneuver);
                        $direction_symbol = isset($direction_symbols[$text_direction]) ? $direction_symbols[$text_direction] : '';
                    } else {
                        $direction_symbol = "";
                    }
                    echo '<div class="distance_part">
                            <div class="above_arrow">
                                <span style="font-size:30px;">' . $direction_symbol . '</span>
                            </div>';
                    echo '<div class="place_name">
                            <p>' . $step->instructions . '</p>
                            <span>' . $step->duration->text . ' ( ' . $step->distance->text . ' )</span>
                        </div>
                    </div>';
                }
                echo '</div></div>';
        }}
            }else{
           echo ' <div class="turn_by_direction">
                <h5 class="heading">Turn-by-Turn Directions:</h5>
                <div class="wrapper">
                    <!-- Accordion Heading One -->
                    <div class="parent-tab">
                        <input type="radio" name="tab" id="tab-1">
                        <label for="tab-1">
                            <span>Est. Travel Time: ' . $route_time . '</span>
                            <div class="icon"><i class="fa-solid fa-chevron-down"></i></div>
                        </label>
                        <div class="content" style="padding: 20px;">
                            <h5>'. $trip_day_starting_address .'</h5>
                            <h6>'. $trip_day_starting_address .'</h6>
                            <div class="track_area">';
                                $url = "https://maps.googleapis.com/maps/api/directions/json?origin=$start_lat,$start_lng&destination=$end_lat,$end_lng&units=imperial&key=".esc_attr(get_option('google_api_key'));
                                $directions_data = wp_remote_get($url);
                                $response_body = wp_remote_retrieve_body($directions_data);
                                $response_data = json_decode($response_body);

                            if ($response_data->status === "OK") {
                                // Iterate through each route and print directions
                                foreach ($response_data->routes as $route) {
                                    echo "Route Summary: " . $route->summary . "<br>";
                                    
                                    // Print each step of the route
                                    foreach ($route->legs as $leg) {
                                        foreach ($leg->steps as $step) {
                                            if(!empty($step->maneuver)){
                                                $text_direction = strtolower($step->maneuver);
                                                $direction_symbol = isset($direction_symbols[$text_direction]) ? $direction_symbols[$text_direction] : '';
                                            }else{ $direction_symbol = ""; }
                                                echo '<div class="distance_part">
                                            <div class="above_arrow">
                                                <span style="font-size:30px;">' . $direction_symbol . '</span>
                                            </div>';
                                        echo '<div class="place_name">
                                            <p>' . $step->html_instructions . '</p>
                                            <span>' . $step->duration->text . ' ( ' . $step->distance->text . ' )</span>
                                        </div>
                                    </div>';

                                        }
                                    }
                                }
                                } else {
                                    // Handle the error if the response status is not OK
                                    echo "Error: Unable to fetch directions.";
                                }
                            
                              echo ' </div>
                            <h5>'. $trip_day_ending_address .'</h5>
                            <h6>'. $trip_day_ending_address .'</h6>
                        </div>
                    </div>

                    <!-- Accordion Heading Two -->
                   <!-- <div class="parent-tab">
                        <input type="radio" name="tab" id="tab-2">
                        <label for="tab-2">
                            <span>Accordion Heading Two</span>
                            <div class="icon"><i class="fa-solid fa-chevron-down"></i></div>
                        </label>
                        <div class="content">
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing thelit. Quam, repellendus facere, id
                                porro magnam blanditiiss quoteos dolores ratione quidem ipsam esse quos pariatur,
                                repellat obcaecati!</p>
                        </div>
                    </div> -->
                </div>
            </div>';
            echo '<div class="address_section">
                            <div class="address_text">
                                <h4>Ending Address:</h4>
                                <p> '. $trip_day_ending_address .'</p>
                            </div>
                        </div>';
        }

            $totl_day = get_post_meta($post_id, '_trip_day_count', true);
            for ($i=1; $i <= $totl_day; $i++) { 
                $current_route = "_route_" . $i;
                $current_value = get_post_meta($post_id, $current_route, true);

                if ($current_value) {
                    if ($i < $day) {
                        $back_url = '?trip_id='. $post_id .'&trip_stay='. $i ;
                    }elseif($i == 1){
                        $back_url = '?trip_id='. $post_id ;
                    }
                    if($i > $day){
                        if (!isset($next_url)) {
                        $next_url = '?trip_id='. $post_id .'&trip_stay='. $i ;
                        }
                    }
                    
                } else {
                    continue;
                }
            }
            echo '<div class="next_pri">
                <a href="'. $back_url .'" class="btn">Back</a>';
             if (isset($next_url)) {
                    echo '<a href="'. $next_url .'" class="btn">Next</a>';
                }
                
           echo '</div>
        </div>';

     }elseif (isset($_GET['trip_stay']) && isset($_GET['dest'])) {
    
      echo '<div class="content_section">
             <div class="one_day">
                <div class="one_day_heading">
                    <h4>Places of Interest:</h4>
                </div>
                <div class="close_btn">
                    <a href="?trip_id='. $post_id .'&trip_stay=' . $_GET['trip_stay'] .'"><i class="fa-regular fa-circle-xmark"></i></a>
                </div>
            </div>';

            $selected_destination_name = "_selected_destinations_" . $_GET['trip_stay'];
            $selected_destinations = get_post_meta($post_id, $selected_destination_name, true);

            if (isset($_GET['dest']) && isset($selected_destinations[$_GET['dest']])) {
                $destination_details = $selected_destinations[$_GET['dest']];
                $destination_id = $_GET['dest'];
                $route_title_name = "_route_title_" . $_GET['trip_stay'];
                $route_title = get_post_meta($post_id, $route_title_name, true);
                $destination_post = get_post($destination_id);
                $destination_title = $destination_post->post_title;
                $destination_address = $destination_details['address'];
                $destination_description = get_post_meta($destination_id, '_destination_description', true);
                $dest_phone = get_post_meta($destination_id, '_destination_phone', true);
                $dest_website = get_post_meta($destination_id, '_destination_website', true);
                $attachment_id = get_post_thumbnail_id($destination_id);
                $file_url = $attachment_id ? wp_get_attachment_url($attachment_id) : plugin_dir_url(__FILE__).'/assets/img/logo_img.png';

            echo '<div class="Interest_details">
                <h4>' . esc_html($destination_title) . '</h4>
                <img src="' . esc_url($file_url) . '" alt="' . esc_html($destination_title) . '" height="auto" width="100%">
            </div>';
            echo '<div class="destination_section">
                    <div class="destinations_area">
                        <div class="location_icon">
                            <i class="fa-solid fa-location-dot"></i>
                        </div>
                        <div class="map_location">
                            <h4>' . esc_html($destination_address) . '</h4>
                        </div>
                    </div>
                    <div class="btn_section">
                        <a href="tel:' . $trip_phone . '" class="btn">Call</a>
                        <a href="' . $dest_website . '" target="_new" class="btn">website</a>
                    </div><hr>
                </div>';
            echo '</ hr>
            <div>
                <p>' . esc_html($destination_description) . '</p>
            </div>
            <center><button class="remove_popup_btn">Remove Destination</button></center>';

            echo '<div class="remove_popup" style="display:none;">
                    <div class="remove-popup-content">
                        <p>Are you sure you want to remove <br><span>' . esc_html($destination_title) . '</span><br> from your itinerary for <span>' . esc_html($route_title) . '</span>?</p>
                        <p>Please Note, this change is permanent and <br> will amend your trun-by-turn directions <br> for the rest of the day.</p>
                        <form method="post">
                        <input type="hidden" name="destination_id" value="'.esc_attr($destination_id) .'">
                        <a class="cancel_remove_btn">Go Back</a>
                       <button class="confirm_remove_btn" type="submit" name="delete_route" value="'. $post_id .'">Remove</button></form>
                    </div>
                </div>';

       }         
    }else{

        if ($number_of_posts > 1) {

        echo '<div class="content_section">
               <div class="one_day">
                <div class="one_day_heading">
                     <h3>Welcome '. $user->display_name .'</h3>
                    <p>Select your trip below to get started!</p>
                </div>
              </div>
            </div>';
    foreach ($posts as $post) {
    
        echo'<div class="day_section_part">
            <div class="day_section">
                <a href="?trip_id='. $post->ID .'">
                <div class="day_btn">'. $post->post_title .'<i class="fa-solid fa-chevron-right"></i>
                </div>
                </a>
            </div>
        </div>';
      }    
     echo'</div>';
     }else{
        $upload_document_trips = get_post_meta($post_id, '_upload_document_trip', true);
                $upload_document_trip = explode(",", $upload_document_trips);
    echo '<div class="content_section">
            <div class="content_area">
                <h3> ' . $trip_title  . ' </h3>
                <p>'. $trip_description .'</p>';

                if(!empty($upload_document_trips)){
                    echo '<div class="upload_btn_wrapper">
                                    <form class="form_data">';
                                        echo '<a class="upload_btn" id="uploadButton">Download Docs</a>
                                    </form>
                                </div>';
                }

            echo '<div class="download_popup" style="display:none;">
                <div class="download-popup-content">
                <span class="close">&times;</span>';
                        echo '<table class="widefat"><tbody>
                        <h4>Download document</h4>';
                    foreach ($upload_document_trip as $value) {
                        $file_path = get_attached_file($value);
                        $file_name = basename($file_path);
                        $file_url = wp_get_attachment_url($value);
                         echo '<tr>
                            <td><b>'. $file_name .'</b></td>
                            <td class="wrap-right">
                            <a class="download_btn" href="'. esc_url($file_url) .'" download>Download</a><br>
                            </td>
                        </tr>';
                    }
                    echo '</tbody>
                        </table></div></div>'; 
              echo  '<div class="venus">
                    <h6>Starting date: '. date($trip_start_date) .'</h6>
                    <h6>Starting location: '. $trip_starting_address .'</h6>
                </div>
            </div>';

        $day = get_post_meta($post_id, '_trip_day_count', true);
        $trip_end_date = date('Y-m-d', strtotime($trip_start_date . ' + ' . $day . ' days'));
        for ($i=1; $i <= $day; $i++) { 

        $current_route = "_route_" . $i;
        $current_title = "_route_title_" . $i;    
        $current_value = get_post_meta($post_id, $current_route, true);
        
        if ($current_value) {
            $current_title = get_post_meta($post_id, $current_title, true);

            echo'<div class="day_section_part">
            <div class="day_section">
                <a href="?trip_id='. $post_id .'&trip_stay='. $i .'">
                <div class="day_btn">'. $current_title .'<i class="fa-solid fa-chevron-right"></i>
                </div>
                </a>
            </div>
        </div>';
        } else {
            continue;
        }
    }

   echo '<div class="content_area">
                <div class="venus">
                    <h6>Ending date: '. date($trip_end_date) .'</h6>
                    <h6>Ending location: ' . $trip_ending_address . '</h6>
                </div>
            </div>
        </div>';
         }
        }
     }else{

        echo '<div class="content_section">
                <div class="content_area">
                    <h4> TRIP NOT FOUND</h4>
              </div>
            </div>';
        }
    }
    else{

        echo '<div class="content_section">
                <div class="content_area">
                    <h4> USER DATA NOT FOUND</h4>
              </div>
            </div>';

    }
    echo '</div>';
return ob_get_clean(); 
}